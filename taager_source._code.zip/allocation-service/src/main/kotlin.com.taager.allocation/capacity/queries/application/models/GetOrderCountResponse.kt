package com.taager.allocation.allocator.queries.application.models
data class GetOrderCountResponse(
    val count: Int
)