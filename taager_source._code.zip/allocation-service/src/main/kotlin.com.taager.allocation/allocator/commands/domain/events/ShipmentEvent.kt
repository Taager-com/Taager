package com.taager.allocation.allocator.commands.domain.events
import com.taager.allocation.sharedkernel.domain.models.base.DomainEvent
interface ShipmentEvent : DomainEvent