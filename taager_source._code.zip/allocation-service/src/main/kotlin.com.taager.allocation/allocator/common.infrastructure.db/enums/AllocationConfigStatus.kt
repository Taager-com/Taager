package com.taager.allocation.allocator.common.infrastructure.db.enums
enum class AllocationConfigStatus {
    ENABLED, DISABLED
}