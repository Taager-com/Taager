package com.taager.allocation.allocator.common.infrastructure.db.enums
enum class AllocationOrderStatus {
    CONFIRMED,
    ALLOCATED,
    SHIPPED_OUT,
    CANCELED
}