package com.taager.allocation.allocator.common.infrastructure.db.interfaces
interface ZoneIdDbResult {
    fun getZoneId(): String
}