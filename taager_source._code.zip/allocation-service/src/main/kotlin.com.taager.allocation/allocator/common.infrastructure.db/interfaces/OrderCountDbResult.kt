package com.taager.allocation.allocator.common.infrastructure.db.interfaces
interface OrderCountDbResult {
    fun getOrderCount(): Int
}