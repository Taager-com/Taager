export interface UploadedImageUrl {
  url: string;
}
