export type IAdminTypes = "superAdmin" | "admin";
