export const PACKAGE_DELIVERY = { name: "Package Delivery", value: 10 };
export const CASH_COLLECTION = { name: "Cash Collection", value: 15 };
export const CUSTOMER_RETURN_PICKUP = {
  name: "Customer Return Pickup",
  value: 25,
};
export const EXCHANGE = { name: "Exchange", value: 30 };