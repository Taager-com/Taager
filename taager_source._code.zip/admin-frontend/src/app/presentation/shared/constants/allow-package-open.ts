export const ALLOW_PACKAGE_OPEN = ["yes", "true"];
