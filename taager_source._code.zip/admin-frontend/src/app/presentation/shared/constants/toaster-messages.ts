export const FILE_NOT_UTF_8_ERROR_MESSAGE =
  "File uploaded is not of UTF8 encoding. Please upload the file after encoding in UTF-8";
export const MISSING_SHIPPING_COMPANY_ERROR =
  "A shipping company must be chosen";